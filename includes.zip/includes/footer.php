<footer>
    <div class="footer">
        <center>
            <p>Copyright © Control Budget. All Rights Reserved|Contact Us: +91-8190847372</p>
        </center>
    </div>
</footer>